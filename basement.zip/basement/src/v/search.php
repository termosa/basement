<div>
	<input name="query" type="search" value="<?php echo $this->s_query; ?>" /> <input type="button" name="search" value="Search">
</div>