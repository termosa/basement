<!doctype html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title><?php echo isset($this->title) ? $this->title : 'Home Page'; ?></title>
</head>
<body>
	<?php echo $content; ?>
</body>
</html>