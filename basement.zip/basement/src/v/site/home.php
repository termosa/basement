<!doctype html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Done!</title>
</head>
<body>
	<h1><?php echo $this->msg; ?></h1>
</body>
</html>