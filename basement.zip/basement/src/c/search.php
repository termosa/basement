<?php
if (isset($_GET['search']) && isset($_GET['query']))
	$this->s_query = $_GET['query'];