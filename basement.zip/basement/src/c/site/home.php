<?php

$title = 'Templates done!';
$this->msg = 'There is msg for you!';
